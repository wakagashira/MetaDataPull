# Changelog

## [0.3.4] - Expanded Flow Parsing
- Expanded Flow XML parser to detect fields in:
  - <field>, <conditionField>
  - <inputAssignments>/<field>, <outputAssignments>/<field>, <assignmentItems>/<field>
  - <formula> and <value> tags (regex-based detection of field references)
- Added DEBUG_FLOW_PARSE flag in .env (default false) to print all field references found during parsing
- Still respects KEEP_FLOW_XML flag

## [0.3.3] - Flow Retrieval via Source API
- Uses `sf force source retrieve -m Flow` (no extra plugin required)
- Parses flow XMLs from force-app/main/default/flows/
- Added KEEP_FLOW_XML flag in .env
